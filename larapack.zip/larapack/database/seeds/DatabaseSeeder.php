<?php

use Illuminate\Database\Seeder;
use Illuminate\Database\Eloquent\Model;

class DatabaseSeeder extends Seeder {

	public function run()
    {
        $this->call('UserTableSeeder');

        $this->command->info('User table seeded!');
    }

}

class UserTableSeeder extends Seeder {

    public function run()
    {
        DB::table('products')->insert([
        	'name' => 'IPhone 3',
        	'image' => 'img1.png',
        	'price' => '10000 USD',
        	'detail' => 'Cosplay IPhone',
        ]);
        DB::table('products')->insert([
        	'name' => 'IPhone XS Max',
        	'image' => 'img2.png',
        	'price' => '2 USD',
        	'detail' => 'Cosplay IPhone XS',
        ]);
    }

}