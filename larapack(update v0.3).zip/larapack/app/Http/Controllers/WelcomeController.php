<?php namespace App\Http\Controllers;
use App\Product;
use Illuminate\Http\Request; 
class WelcomeController extends Controller {

	/*
	|--------------------------------------------------------------------------
	| Welcome Controller
	|--------------------------------------------------------------------------
	|
	| This controller renders the "marketing page" for the application and
	| is configured to only allow guests. Like most of the other sample
	| controllers, you are free to modify or remove it as you desire.
	|
	*/

	/**
	 * Create a new controller instance.
	 *
	 * @return void
	 */
	public function __construct()
	{
		$this->middleware('guest');
	}

	/**
	 * Show the application welcome screen to the user.
	 *
	 * @return Response
	 */
	public function index()
	{
		$products = Product::all();
		return view('braselling/index',['data' => $products]);
	}

	public function page($page = "index")
	{
		$products = Product::all();
		return view('braselling/'.$page,['data' => $products]);
	}
	public function details($id)
	{
		$product = Product::find($id);
		return view('braselling/product-details', ['data' => $product]);
	}
	public function search(Request $request)
	{
		$name = $request->tukhoa;
		$product = Product::where('name', 'like', "%".$name."%")->paginate(1);
		return view('braselling/search', ['data' => $product, 'name' => $name]);
	}

	public function product($id)
	{
		$model = Product::where('id', '<', '5')->get();
		$product = Product::find($id);
		return view('product', ['data'=>$product], ['product' => $model]);
	}
}
