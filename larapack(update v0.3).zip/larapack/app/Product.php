<?php namespace App;

use Illuminate\Database\Eloquent\Model;

class Product extends Model {

	public $timestamps = false;
	public $primaryKey = "ID";

	public function getManufacture(){
	return $this->belongsTo('App\Manufacture','manu_id');
	}

	public function getProtype(){
	return $this->belongsTo('App\Protype','type_id');
	}

}