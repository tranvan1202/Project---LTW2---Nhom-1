<?php

use Illuminate\Database\Seeder;
use Illuminate\Database\Eloquent\Model;

class DatabaseSeeder extends Seeder {

	public function run()
    {
        $this->call('UserTableSeeder');

        $this->command->info('User table seeded!');
    }

}

class UserTableSeeder extends Seeder {

    public function run()
    {
        DB::table('products')->insert([
        	'name' => 'IPhone 3',
        	'image' => 'img1.png',
        	'price' => '10000',
        	'detail' => 'Cosplay IPhone',
        ]);
        DB::table('products')->insert([
        	'name' => 'IPhone XS Max',
        	'image' => 'img2.png',
        	'price' => '2',
        	'detail' => 'Cosplay IPhone XS',
        ]);
        DB::table('products')->insert([
            'name' => 'Nokia',
            'image' => 'img3.png',
            'price' => '2',
            'detail' => 'Cosplaaaay',
        ]);
        DB::table('products')->insert([
            'name' => 'Samsung',
            'image' => 'img4.png',
            'price' => '2',
            'detail' => 'Cosplay',
        ]);
        DB::table('products')->insert([
            'name' => 'XBox',
            'image' => 'img5.png',
            'price' => '8',
            'detail' => 'Cooooosplay',
        ]);
        DB::table('products')->insert([
            'name' => 'Galaxy',
            'image' => 'img6.png',
            'price' => '200',
            'detail' => 'Cossssssplay',
        ]);
    }

}