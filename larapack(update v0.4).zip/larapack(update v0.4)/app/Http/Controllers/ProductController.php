<?php namespace App\Http\Controllers;
use App\product;
use Illuminate\Http\Request;
class ProductContronller extends Controller {
	public function __construct()
	{
		$this->middleware('auth');
	}
	public function index(){
		//Thuc thi cau truy van
		$product = Product::paginate(6);
		//$product->setPath('product');
		return view('/admin/admin',['data'=>$product]);
	}

	public function create(){
		//Thuc thi cau truy van
		return view('/admin/create');
	}


	public function store(request $request){
		$product = new Product;
		$product->name = $request->name;
		$product->type_id = $request->type_id;
		$product->manu_id = $request->manu_id;
		if ($request->hasFile('fileUpload')) {
			$file = $request->file('fileUpload');
			$image = $file->getClientOriginalName();
			$product->image = $image;
		}
		$product->price = $request->price;
		$product->description = $request->description;
		$product->save();
		//upload
		$ok = 'ĐÃ CẬP NHẬT';

		$file->move('images', $file->getClientOriginalName());
		return view('/admin/create',['data' => $ok]);
	}

	public function edit($id){
		$product = Product::find($id);

		return view('/admin/edit',['edit'=>$product]);
	}

	public function update(Request $request, $id)
	{
		$product = Product::find($id);
		$product->name = $request->name;
		$product->type_id = $request->type_id;
		$product->manu_id = $request->manu_id;
		if ($request->hasFile('fileUpload')) {
			$file = $request->file('fileUpload');
			$image = $file->getClientOriginalName();
			$file->move('images', $file->getClientOriginalName());
			$product->image = $image;
		}
		$product->price = $request->price;
		$product->description = $request->description;
		$product->save();
		//upload
		return $this->index();
	}

	public function destroy($id){
		$product = Product::find($id);
		$product->delete();
		return $this->index();	}
		
	}