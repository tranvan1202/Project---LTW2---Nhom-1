<?php namespace App\Http\Controllers;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\Product;
use Illuminate\Support\Facades\Request;
use Illuminate\Support\Facades\Redirect;
use Cart;

class Front extends Controller {

	public function cart(Request $request) 
	{
    	if (Request::isMethod('post')) 
    	{
	        $product_id = Request::get('product_id');
	        $product = Product::find($product_id);
	        $image = $product->image;
	        Cart::add(array('id' => $product_id, 'name' => $product->name, 'image' => $product->image,  'qty' => 1, 'price' => $product->price));
	    }

	    $cart = Cart::content();

	    return view('braselling/cart', array('cart' => $cart, 'image' => $image, 'title' => 'Welcome', 'description' => '', 'page' => 'home'));
	}

}
